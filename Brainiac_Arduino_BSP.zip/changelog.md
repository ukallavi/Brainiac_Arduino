# Brainiac Arduino Changelog

## 0.0.1

- Initial release
